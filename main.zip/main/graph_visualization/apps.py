from django.apps import AppConfig


class GraphVisualizationConfig(AppConfig):
    name = 'graph_visualization'
